package com.learvia.app

import android.app.Application
import com.learvia.app.data.AppDatabase
import com.learvia.app.data.LibraryRepository

class LearviaApp : Application() {
    private val database by lazy { AppDatabase.create(this) }
    val repository by lazy { LibraryRepository(database.dao()) }
}
