package com.learvia.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

// exportSchema is off for the first slice; turn it on (with a schema dir) before the first migration.
@Database(
    entities = [CourseEntity::class, SubjectEntity::class, ChapterEntity::class, ClassEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): LibraryDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "learvia.db").build()
    }
}
