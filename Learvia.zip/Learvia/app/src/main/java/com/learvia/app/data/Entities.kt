package com.learvia.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class NodeKind { COURSE, SUBJECT, CHAPTER, CLASS }

@Entity(tableName = "courses")
data class CourseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val thumbnailUri: String? = null,
    val sortOrder: Int = 0,
)

@Entity(
    tableName = "subjects",
    foreignKeys = [ForeignKey(CourseEntity::class, ["id"], ["courseId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("courseId")],
)
data class SubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val courseId: Long,
    val title: String,
    val description: String = "",
    val thumbnailUri: String? = null,
    val sortOrder: Int = 0,
)

/** subjectId == null means the chapter sits directly under the course (Subject is optional). */
@Entity(
    tableName = "chapters",
    foreignKeys = [
        ForeignKey(CourseEntity::class, ["id"], ["courseId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(SubjectEntity::class, ["id"], ["subjectId"], onDelete = ForeignKey.CASCADE),
    ],
    indices = [Index("courseId"), Index("subjectId")],
)
data class ChapterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val courseId: Long,
    val subjectId: Long? = null,
    val title: String,
    val description: String = "",
    val thumbnailUri: String? = null,
    val sortOrder: Int = 0,
)

/** The video is stored only as a SAF URI reference; the file itself is never copied or modified. */
@Entity(
    tableName = "classes",
    foreignKeys = [ForeignKey(ChapterEntity::class, ["id"], ["chapterId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("chapterId")],
)
data class ClassEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chapterId: Long,
    val title: String,
    val description: String = "",
    val thumbnailUri: String? = null,
    val mediaUri: String? = null,
    val mediaName: String? = null,
    val lastPositionMs: Long = 0,
    val durationMs: Long = 0,
    val sortOrder: Int = 0,
)
