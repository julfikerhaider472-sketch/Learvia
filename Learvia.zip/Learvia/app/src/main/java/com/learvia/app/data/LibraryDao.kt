package com.learvia.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LibraryDao {
    @Query("SELECT * FROM courses ORDER BY sortOrder, id") fun courses(): Flow<List<CourseEntity>>
    @Query("SELECT * FROM subjects ORDER BY sortOrder, id") fun subjects(): Flow<List<SubjectEntity>>
    @Query("SELECT * FROM chapters ORDER BY sortOrder, id") fun chapters(): Flow<List<ChapterEntity>>
    @Query("SELECT * FROM classes ORDER BY sortOrder, id") fun classes(): Flow<List<ClassEntity>>

    @Query("SELECT * FROM classes WHERE id = :id") suspend fun classById(id: Long): ClassEntity?

    @Insert suspend fun insertCourse(e: CourseEntity): Long
    @Insert suspend fun insertSubject(e: SubjectEntity): Long
    @Insert suspend fun insertChapter(e: ChapterEntity): Long
    @Insert suspend fun insertClass(e: ClassEntity): Long

    @Query("UPDATE courses SET title = :t WHERE id = :id") suspend fun renameCourse(id: Long, t: String)
    @Query("UPDATE subjects SET title = :t WHERE id = :id") suspend fun renameSubject(id: Long, t: String)
    @Query("UPDATE chapters SET title = :t WHERE id = :id") suspend fun renameChapter(id: Long, t: String)
    @Query("UPDATE classes SET title = :t WHERE id = :id") suspend fun renameClass(id: Long, t: String)

    // Deleting removes Learvia metadata only (FK cascade). Original media files are never touched.
    @Query("DELETE FROM courses WHERE id = :id") suspend fun deleteCourse(id: Long)
    @Query("DELETE FROM subjects WHERE id = :id") suspend fun deleteSubject(id: Long)
    @Query("DELETE FROM chapters WHERE id = :id") suspend fun deleteChapter(id: Long)
    @Query("DELETE FROM classes WHERE id = :id") suspend fun deleteClass(id: Long)

    @Query("UPDATE classes SET mediaUri = :uri, mediaName = :name WHERE id = :id")
    suspend fun setMedia(id: Long, uri: String?, name: String?)

    @Query("UPDATE courses SET thumbnailUri = :u WHERE id = :id") suspend fun setCourseThumb(id: Long, u: String?)
    @Query("UPDATE subjects SET thumbnailUri = :u WHERE id = :id") suspend fun setSubjectThumb(id: Long, u: String?)
    @Query("UPDATE chapters SET thumbnailUri = :u WHERE id = :id") suspend fun setChapterThumb(id: Long, u: String?)
    @Query("UPDATE classes SET thumbnailUri = :u WHERE id = :id") suspend fun setClassThumb(id: Long, u: String?)

    @Query("UPDATE classes SET lastPositionMs = :pos, durationMs = :dur WHERE id = :id")
    suspend fun savePosition(id: Long, pos: Long, dur: Long)
}
