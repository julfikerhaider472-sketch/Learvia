package com.learvia.app.data

class LibraryRepository(private val dao: LibraryDao) {
    val courses = dao.courses()
    val subjects = dao.subjects()
    val chapters = dao.chapters()
    val classes = dao.classes()

    suspend fun classById(id: Long) = dao.classById(id)

    suspend fun addCourse(title: String) = dao.insertCourse(CourseEntity(title = title))
    suspend fun addSubject(courseId: Long, title: String) = dao.insertSubject(SubjectEntity(courseId = courseId, title = title))
    suspend fun addChapter(courseId: Long, subjectId: Long?, title: String) =
        dao.insertChapter(ChapterEntity(courseId = courseId, subjectId = subjectId, title = title))
    suspend fun addClass(chapterId: Long, title: String) = dao.insertClass(ClassEntity(chapterId = chapterId, title = title))

    suspend fun rename(kind: NodeKind, id: Long, title: String) = when (kind) {
        NodeKind.COURSE -> dao.renameCourse(id, title)
        NodeKind.SUBJECT -> dao.renameSubject(id, title)
        NodeKind.CHAPTER -> dao.renameChapter(id, title)
        NodeKind.CLASS -> dao.renameClass(id, title)
    }

    suspend fun delete(kind: NodeKind, id: Long) = when (kind) {
        NodeKind.COURSE -> dao.deleteCourse(id)
        NodeKind.SUBJECT -> dao.deleteSubject(id)
        NodeKind.CHAPTER -> dao.deleteChapter(id)
        NodeKind.CLASS -> dao.deleteClass(id)
    }

    suspend fun setThumbnail(kind: NodeKind, id: Long, uri: String?) = when (kind) {
        NodeKind.COURSE -> dao.setCourseThumb(id, uri)
        NodeKind.SUBJECT -> dao.setSubjectThumb(id, uri)
        NodeKind.CHAPTER -> dao.setChapterThumb(id, uri)
        NodeKind.CLASS -> dao.setClassThumb(id, uri)
    }

    suspend fun setMedia(classId: Long, uri: String?, name: String?) = dao.setMedia(classId, uri, name)
    suspend fun savePosition(classId: Long, pos: Long, dur: Long) = dao.savePosition(classId, pos, dur)
}
