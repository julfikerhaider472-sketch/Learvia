package com.learvia.app.ui

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.learvia.app.ui.screens.ChapterScreen
import com.learvia.app.ui.screens.CourseScreen
import com.learvia.app.ui.screens.LibraryScreen
import com.learvia.app.ui.screens.ManagementScreen
import com.learvia.app.ui.screens.PlayerScreen
import com.learvia.app.ui.screens.SettingsScreen

private val idArg = listOf(navArgument("id") { type = NavType.LongType })

@Composable
fun LearviaNav() {
    val nav = rememberNavController()
    val vm: LibraryViewModel = viewModel()
    val back: () -> Unit = { nav.popBackStack() }

    NavHost(nav, startDestination = "library") {
        composable("library") {
            LibraryScreen(vm, { nav.navigate("course/$it") }, { nav.navigate("settings") }, { nav.navigate("manage") })
        }
        composable("course/{id}", idArg) {
            CourseScreen(vm, it.arguments!!.getLong("id"), back) { ch -> nav.navigate("chapter/$ch") }
        }
        composable("chapter/{id}", idArg) {
            ChapterScreen(vm, it.arguments!!.getLong("id"), back) { cls -> nav.navigate("player/$cls") }
        }
        composable("player/{id}", idArg) { PlayerScreen(vm, it.arguments!!.getLong("id"), back) }
        composable("settings") { SettingsScreen(back) { nav.navigate("manage") } }
        composable("manage") { ManagementScreen(vm, back) }
    }
}
