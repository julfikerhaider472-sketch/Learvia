package com.learvia.app.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.learvia.app.LearviaApp
import com.learvia.app.data.NodeKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LibraryViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as LearviaApp).repository
    private fun <T> kotlinx.coroutines.flow.Flow<List<T>>.state() =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val courses = repo.courses.state()
    val subjects = repo.subjects.state()
    val chapters = repo.chapters.state()
    val classes = repo.classes.state()

    suspend fun classById(id: Long) = repo.classById(id)

    fun addCourse(title: String) = viewModelScope.launch { repo.addCourse(title.trim()) }
    fun addSubject(courseId: Long, title: String) = viewModelScope.launch { repo.addSubject(courseId, title.trim()) }
    fun addChapter(courseId: Long, subjectId: Long?, title: String) =
        viewModelScope.launch { repo.addChapter(courseId, subjectId, title.trim()) }
    fun addClass(chapterId: Long, title: String) = viewModelScope.launch { repo.addClass(chapterId, title.trim()) }
    fun rename(kind: NodeKind, id: Long, title: String) = viewModelScope.launch { repo.rename(kind, id, title.trim()) }
    fun delete(kind: NodeKind, id: Long) = viewModelScope.launch { repo.delete(kind, id) }

    /** Stores a persisted SAF reference only. The video file is never copied, moved or modified. */
    fun assignVideo(classId: Long, uri: Uri) = viewModelScope.launch {
        val cr = getApplication<Application>().contentResolver
        val name = withContext(Dispatchers.IO) {
            try {
                cr.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) {
                // Provider may not allow persistable grants; playback may fail after restart (handled as "unavailable").
            }
            cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }
        repo.setMedia(classId, uri.toString(), name)
    }

    /** Thumbnails are also kept as persisted references; the image file is not copied. */
    fun setThumbnail(kind: NodeKind, id: Long, uri: Uri) = viewModelScope.launch {
        val cr = getApplication<Application>().contentResolver
        withContext(Dispatchers.IO) {
            try {
                cr.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) { }
        }
        repo.setThumbnail(kind, id, uri.toString())
    }

    fun savePosition(classId: Long, pos: Long, dur: Long) =
        viewModelScope.launch { repo.savePosition(classId, pos.coerceAtLeast(0), dur.coerceAtLeast(0)) }
}
