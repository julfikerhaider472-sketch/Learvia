package com.learvia.app.ui.screens

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.layout.Arrangement.spacedBy
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.learvia.app.R
import com.learvia.app.ui.LibraryViewModel

@Composable
fun LibraryScreen(vm: LibraryViewModel, onCourse: (Long) -> Unit, onSettings: () -> Unit, onManage: () -> Unit) {
    val courses by vm.courses.collectAsStateWithLifecycle()
    ScreenScaffold(
        title = stringResource(R.string.app_name),
        actions = {
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, stringResource(R.string.settings)) }
        },
    ) { pad ->
        if (courses.isEmpty()) {
            CenterMessage(
                stringResource(R.string.empty_library_title),
                stringResource(R.string.empty_library_hint),
                pad,
            ) { Button(onClick = onManage) { Text(stringResource(R.string.open_management)) } }
        } else {
            LazyColumn(contentPadding = contentPadding(pad), verticalArrangement = spacedBy(12.dp)) {
                items(courses, key = { it.id }) { c ->
                    InfoRow(c.title, c.description.ifBlank { null }, thumbnailUri = c.thumbnailUri) { onCourse(c.id) }
                }
            }
        }
    }
}
