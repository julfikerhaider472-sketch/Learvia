package com.learvia.app.ui.screens

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.learvia.app.R
import com.learvia.app.data.ClassEntity
import com.learvia.app.ui.LibraryViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private sealed interface Load {
    data object Loading : Load
    data object Missing : Load
    data class Ready(val cls: ClassEntity) : Load
}

private suspend fun canOpen(ctx: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
    try {
        ctx.contentResolver.openFileDescriptor(uri, "r")?.use { true } ?: false
    } catch (_: Exception) {
        false
    }
}

@Composable
fun PlayerScreen(vm: LibraryViewModel, classId: Long, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var load by remember { mutableStateOf<Load>(Load.Loading) }

    LaunchedEffect(classId) {
        val c = vm.classById(classId)
        load = if (c?.mediaUri != null && canOpen(ctx, Uri.parse(c.mediaUri))) Load.Ready(c) else Load.Missing
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        when (val l = load) {
            Load.Loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
            Load.Missing -> CenterMessage(
                stringResource(R.string.media_missing_title), stringResource(R.string.media_missing_body),
            )
            is Load.Ready -> PlayerContent(l.cls) { pos, dur -> vm.savePosition(l.cls.id, pos, dur) }
        }
        IconButton(onClick = onBack, Modifier.statusBarsPadding().padding(4.dp).align(Alignment.TopStart)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back))
        }
    }
}

@Composable
private fun PlayerContent(c: ClassEntity, onSave: (Long, Long) -> Unit) {
    val ctx = LocalContext.current
    var failed by remember { mutableStateOf(false) }
    var clamped by remember { mutableStateOf(false) }

    val player = remember(c.id) {
        ExoPlayer.Builder(ctx)
            .setSeekBackIncrementMs(SEEK_MS)
            .setSeekForwardIncrementMs(SEEK_MS)
            .build().apply {
            setMediaItem(MediaItem.fromUri(Uri.parse(c.mediaUri)), c.lastPositionMs)
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) { failed = true }
            override fun onPlaybackStateChanged(state: Int) {
                // Never resume beyond the file's real duration (LP-001 edge case).
                if (state == Player.STATE_READY && !clamped) {
                    clamped = true
                    val d = player.duration
                    if (d != C.TIME_UNSET && player.currentPosition >= d - 1_000) player.seekTo(0)
                }
            }
        }
        player.addListener(listener)
        onDispose {
            onSave(player.currentPosition, player.duration.let { if (it == C.TIME_UNSET) 0 else it })
            player.removeListener(listener)
            player.release()
        }
    }

    // Pause when the app leaves the foreground; background playback is a later, separate feature (VP-006).
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner, player) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) player.pause() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    // Placeholder save interval; the final rule is still an open product decision (LP-001).
    LaunchedEffect(player) {
        while (true) {
            delay(5_000)
            if (player.isPlaying) onSave(player.currentPosition, player.duration.let { if (it == C.TIME_UNSET) 0 else it })
        }
    }

    var viewRef by remember { mutableStateOf<PlayerView?>(null) }
    var feedback by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(feedback) {
        if (feedback != null) { delay(700); feedback = null }
    }
    fun seekBy(delta: Long) {
        val d = player.duration
        val target = player.currentPosition + delta
        player.seekTo(if (d == C.TIME_UNSET) target.coerceAtLeast(0) else target.coerceIn(0, d))
        feedback = if (delta < 0) "−${SEEK_MS / 1000}s" else "+${SEEK_MS / 1000}s"
    }
    fun toggleControls() {
        viewRef?.let { if (it.isControllerFullyVisible) it.hideController() else it.showController() }
    }

    if (failed) {
        CenterMessage(null, stringResource(R.string.playback_error))
    } else {
        Box(Modifier.fillMaxSize()) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { PlayerView(it).apply { this.player = player; useController = true }.also { v -> viewRef = v } },
            )
            // Double-tap left/right third to seek. The centre and bottom stay free so the
            // built-in controls (play/pause, seekbar, rewind/forward buttons) remain usable.
            Row(Modifier.align(Alignment.Center).fillMaxWidth().fillMaxHeight(0.6f)) {
                SeekZone(Modifier.weight(1f), { seekBy(-SEEK_MS) }, ::toggleControls)
                Spacer(Modifier.weight(1.2f))
                SeekZone(Modifier.weight(1f), { seekBy(SEEK_MS) }, ::toggleControls)
            }
            feedback?.let {
                Text(
                    it,
                    Modifier.align(Alignment.Center).background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(12.dp)).padding(horizontal = 16.dp, vertical = 8.dp),
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                )
            }
        }
    }
}

@Composable
private fun SeekZone(modifier: Modifier, onDouble: () -> Unit, onSingle: () -> Unit) {
    Box(
        modifier.fillMaxHeight().pointerInput(Unit) {
            detectTapGestures(onDoubleTap = { onDouble() }, onTap = { onSingle() })
        },
    )
}

// Placeholder default; the final seek-interval range/default is an open product decision (TBD-12).
private const val SEEK_MS = 10_000L
