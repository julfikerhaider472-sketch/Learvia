package com.learvia.app.ui.screens

import androidx.compose.foundation.layout.Arrangement.spacedBy
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.learvia.app.R

@Composable
fun SettingsScreen(onBack: () -> Unit, onManage: () -> Unit) {
    ScreenScaffold(stringResource(R.string.settings), onBack) { pad ->
        Column(Modifier.padding(contentPadding(pad)), verticalArrangement = spacedBy(12.dp)) {
            // Management stays a secondary entry inside Settings.
            InfoRow(stringResource(R.string.management), stringResource(R.string.management_hint), onClick = onManage)
            InfoRow(stringResource(R.string.about), stringResource(R.string.about_body), enabled = false) {}
        }
    }
}
